package com.example.ems.model;

public class PaymentRecord {

}
